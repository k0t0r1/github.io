const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)


var weather = ["sunny","rainy","cloudy"]
console.log(weather)
for (let i = 0; i < weather.length; ++i) {
  console.log(weather[i]);
}


sum = 0;
for(i=1; i<=100; i++){
sum += i;
}
console.log(sum);